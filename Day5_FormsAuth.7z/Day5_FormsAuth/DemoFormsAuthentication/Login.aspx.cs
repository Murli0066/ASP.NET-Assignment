﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace DemoFormsAuthentication
{
    public partial class Login : System.Web.UI.Page
    {
               protected void Logon_Click(object sender, EventArgs e)
        {
            if ((UserEmail.Text == "Training@capgemini.com") &&
            (UserPass.Text == "sqluser"))
            {
                FormsAuthentication.RedirectFromLoginPage
                   (UserEmail.Text, Persist.Checked);
            }
            else
            {
                Msg.Text = "Invalid credentials. Please try again.";
            }
        }
    }
}