﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = DropDownList1.SelectedIndex;
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        
        //if (FormsAuthentication.Authenticate(txtname.Text, txtpwd.Text))
        //{
        //    FormsAuthentication.RedirectFromLoginPage(txtname.Text, CheckBox1.Checked);
            
        //}
    }
}