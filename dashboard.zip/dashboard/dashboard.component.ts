import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import * as Chartist from 'chartist';
import { DataService } from '../service/data.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { Alert } from 'selenium-webdriver';
import { Observable, interval } from "rxjs";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EmployeeInformationComponent } from '../employee-information/employee-information.component'
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  width: number = 25;
  person1Right: number = 27
  person1Top: number = 173
  person2Top: number = 173
  person2Right: number = 27;
  floars: any;
  floar1: string = 'First Line';
  xPos: number = 27;
  yPos: number = 0;
  constructor(public dialog: MatDialog, private router: Router, private serv: DataService,
    private toastr: ToastrService, private spinner: NgxSpinnerService) {
  }



  ngOnInit() {
    this.floars = ['First Line', 'Second Line', 'Third Line']
    const source = interval(10);
    const subscribe = source.subscribe(val => {
      if (this.person1Top == 530 && this.person1Right == 290) {
        //this will cancel the subscription to the observable
        this.person1Right = 27
        this.person1Top = 173
        this.person2Top = 173
        this.person2Right = 27

      } else {
        this.myCallback();
        this.callPerson2();
      }

    });
  }


  callPerson2() {
    if (this.person2Right < 500) {
      this.person2Right = (this.person2Right + 1)
      console.log(this.person2Right)
    }
  }

  myCallback() {
    if (this.person1Top === 530 && this.person1Right < 290) {
      this.person1Right = (this.person1Right + 1)
      console.log(this.person1Right)
    }
    else if (this.person1Right < 110) {
      this.person1Right = (this.person1Right + 1)
      console.log(this.person1Right)
    } else if (this.person1Top < 530) {
      this.person1Top = (this.person1Top + 1)
      console.log(this.person1Top)
    }
    else if (this.person1Top === 530) {
      this.person1Top = (this.person1Top - 1)
    }
  }

  personPialog(event) {
    console.log('event', event);
    const dialogRef = this.dialog.open(EmployeeInformationComponent, {
      width: '250px',
      data: {}
    });
  }

  wareHouse() {
    const dialogRef = this.dialog.open(EmployeeInformationComponent, {
      width: '250px',
      data: {}
    });
  }



}



