using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;


public partial class ProfileSamples_Sample2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
            LoadUsers();
    }

    private void LoadUsers()
    {
        foreach (MembershipUser user in Membership.GetAllUsers())
        {
            DropDownList1.Items.Add(user.UserName);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Employee empObj = new Employee();
        empObj.EmployeeID = Convert.ToInt32(TextBox1.Text);
        empObj.EmployeeName = TextBox2.Text;
        Profile.Emp = empObj;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Employee empObj = Profile.Emp;
        TextBox1.Text = empObj.EmployeeID.ToString();
        TextBox2.Text = empObj.EmployeeName;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        ProfileCommon profile = Profile.GetProfile(DropDownList1.SelectedItem.Text);
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Page Hit : {0} <br/><br/>", profile.PageHit);
        sb.AppendFormat("Capgemini Grade : {0} <br/><br/>", profile.Capgemini.Grade);
        Label1.Text = sb.ToString();

    }
}
