﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        //if(!IsPostBack)
        //{
            //Using QueryString
            //string str = Request.QueryString["ln"];
            //if (str == null)           //string.IsNullorEmpty(str)
            //{
            //    lbllogin.Text = "Guest";
            //}
            //else
            //{
            //    lbllogin.Text = " Login-Name :"+str+" Password :"+Request.QueryString["pw"];
            //}

            //Using Cookies
        //    HttpCookie ck1 = Request.Cookies["ln"];
        //    if(ck1==null)
        //    {
        //        lbllogin.Text = "Guest";
        //    }
        //    else
        //    {
        //        lbllogin.Text = ck1.Value;
        //    }
        //}

        LoginUser user = (LoginUser)Session["user"];
        lbllogin.Text = user.UserFullName;
        lblLiveUsers.Text = Application["LiveUserNumber"].ToString();
    }
    protected void btnlogoff_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }
}