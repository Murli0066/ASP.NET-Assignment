﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        List<LoginUser> loginUser = LoginUser.GetSampleData();
     
        var query = (from s in loginUser
                           where (txtname.Text.Equals(s.LoginName) && txtpwd.Text.Equals(s.Password))
                           select s).SingleOrDefault();

        if(query!=null)
        {
            Session["user"] = query;
            Response.Redirect("Home.aspx");
        }
        else
        {
            lblError.Text = "Invalid Login-Name and Password";
        }
        //if(txtname.Text.Equals("Admin") && txtpwd.Text.Equals("Admin"))
        //{
        //    //Using QueryString
        //    //string str = "Home.aspx?ln=" + txtname.Text + "&pw=" + txtpwd.Text;
        //    //this.Response.Redirect(str);


        //    //Cookies
        //    HttpCookie ck1 = new HttpCookie("ln",txtname.Text);
        //    Response.Cookies.Add(ck1);
        //    Response.Redirect("Home.aspx");
        //}
        //else
        //{
        //    Response.Write("Invalid Login Name or Password.");
        //}
    }
}