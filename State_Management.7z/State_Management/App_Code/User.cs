﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for User
/// </summary>
public class LoginUser
{
	public enum HighestQualification
    {
        UnderGraduate,Graduate,PostGraduate,SSC,HSC
    }
    public string LoginName { get; set; }
    public string UserFullName { get; set; }
    public DateTime DOB { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }
    public HighestQualification HighQual { get; set; }

    public static List<LoginUser> GetSampleData()
    {
        List<LoginUser> users=new List<LoginUser>
        {
            new LoginUser{UserFullName="Murli",DOB=DateTime.Now.AddMonths(254),Email="murli@gmail.com",HighQual=HighestQualification.UnderGraduate,LoginName="murli",Password="0066"},
            new LoginUser{UserFullName="Murali",DOB=DateTime.Now.AddMonths(250),Email="murali@gmail.com",HighQual=HighestQualification.PostGraduate,LoginName="1",Password="1"},
            new LoginUser{UserFullName="Murlia",DOB=DateTime.Now.AddMonths(270),Email="murlia@gmail.com",HighQual=HighestQualification.Graduate,LoginName="Murlidhara",Password="0068"}
        };
        return users;
    }
}